// Add a "checked" symbol when clicking on a list item
var list = document.getElementById('todoList');
list.addEventListener('click', function(ev) {
  if (ev.target.tagName === 'LI') {
    ev.target.classList.toggle('checked');
  }
}, false);

// Get the incomplete tasks list
var incompleteTasksList = document.getElementById('todoList');

// Get the completed tasks list
var completedTasksList = document.getElementById('completedList');

// Loop through the incomplete tasks list
incompleteTasksList.querySelectorAll('li').forEach(function(li) {

  // Add an event listener to the incomplete task
  li.addEventListener('click', function() {

    // Show a prompt to the user
    var confirmation = window.confirm('Are you sure you want to mark this task as completed?');

    // If the user clicks "Yes", move the task to the completed tasks list
    if (confirmation) {
      completedTasksList.appendChild(li);
      var br = document.createElement('br');
      completedTasksList.appendChild(br);
      incompleteTasksList.removeChild(li);
    }

  });
});
 




